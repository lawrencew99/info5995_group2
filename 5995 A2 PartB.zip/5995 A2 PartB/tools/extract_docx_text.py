from __future__ import annotations

import sys
from pathlib import Path

from docx import Document


def extract_docx_text(docx_path: Path) -> str:
    doc = Document(str(docx_path))

    lines: list[str] = []

    for para in doc.paragraphs:
        t = (para.text or "").strip()
        if t:
            lines.append(t)

    for tbl in doc.tables:
        for row in tbl.rows:
            cells = [(c.text or "").replace("\n", " ").strip() for c in row.cells]
            if any(cells):
                lines.append("\t".join(cells))

    return "\n".join(lines).strip() + "\n"


def main(argv: list[str]) -> int:
    if len(argv) != 3:
        print("Usage: python extract_docx_text.py <input.docx> <output.txt>", file=sys.stderr)
        return 2

    inp = Path(argv[1]).expanduser().resolve()
    out = Path(argv[2]).expanduser().resolve()
    out.parent.mkdir(parents=True, exist_ok=True)

    text = extract_docx_text(inp)
    out.write_text(text, encoding="utf-8")
    print(str(out))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))

