from __future__ import annotations

from pathlib import Path

from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN
from pptx.util import Inches, Pt


def _set_run_style(run, *, size_pt: int = 20, bold: bool = False, rgb=(20, 20, 20)) -> None:
    run.font.size = Pt(size_pt)
    run.font.bold = bold
    run.font.color.rgb = RGBColor(*rgb)


def add_title_and_bullets(
    prs: Presentation,
    title: str,
    bullets: list[str],
    *,
    subtitle: str | None = None,
) -> None:
    slide = prs.slides.add_slide(prs.slide_layouts[5])  # Title Only

    # Title
    title_box = slide.shapes.title
    title_box.text_frame.clear()
    p = title_box.text_frame.paragraphs[0]
    p.text = title
    p.alignment = PP_ALIGN.LEFT
    _set_run_style(p.runs[0], size_pt=34, bold=True, rgb=(10, 31, 61))

    # Optional subtitle
    top = Inches(1.25)
    if subtitle:
        sub = slide.shapes.add_textbox(Inches(0.9), top, Inches(12.4), Inches(0.6))
        tf = sub.text_frame
        tf.clear()
        sp = tf.paragraphs[0]
        sp.text = subtitle
        sp.alignment = PP_ALIGN.LEFT
        _set_run_style(sp.runs[0], size_pt=18, bold=False, rgb=(80, 80, 80))
        top = Inches(1.85)

    # Bullets
    body = slide.shapes.add_textbox(Inches(0.9), top, Inches(12.4), Inches(5.0))
    tf = body.text_frame
    tf.clear()
    tf.word_wrap = True
    for i, b in enumerate(bullets):
        para = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        para.text = b
        para.level = 0
        para.space_after = Pt(8)
        para.space_before = Pt(0)
        para.line_spacing = 1.15
        if para.runs:
            _set_run_style(para.runs[0], size_pt=22)


def build_deck(output_path: Path) -> None:
    prs = Presentation()
    prs.slide_width = Inches(13.333)  # 16:9 widescreen
    prs.slide_height = Inches(7.5)

    add_title_and_bullets(
        prs,
        "Quick Briefing: Two Security Reports",
        [
            "Report A: Cengage (Bugcrowd) — Web IDOR / Broken Access Control (HIGH)",
            "Report B: Microsoft Copilot for Android — exported components found via static analysis (2×MEDIUM, pending dynamic validation)",
            "Goal: cover findings, impact, and remediation recommendations (within 4 minutes)",
            "Timing: Speaker 1 opening/closing; Speakers 2–3 Web; Speakers 4–5 Android",
        ],
        subtitle="Team briefing (6 slides)",
    )

    add_title_and_bullets(
        prs,
        "Report A: What is the vulnerability? (Speaker 2)",
        [
            "Type: IDOR / OWASP A01 Broken Access Control",
            "Location: learn.cengage.com.au",
            "Entry point: URL parameters course_id / lesson_id",
            "Root cause: missing server-side authorization checks → changing IDs enables unauthorized resource access",
            "Exploitability: no special tools; can modify/enumerate parameters directly in a browser",
        ],
    )

    add_title_and_bullets(
        prs,
        "Report A: Impact & Fix (Speaker 3)",
        [
            "Impact: unauthorized access to course/lesson content; may expose student records and privacy",
            "Risk: easy to enumerate and low effort to exploit → high priority",
            "Broader impact: potential academic integrity issues plus compliance/reputational risk",
            "Fix: enforce server-side RBAC/ACL authorization (user ↔ course/lesson bindings)",
            "Fix: add logging and alerting for enumeration behavior",
            "Regression test: access to the same resource under different identities must be denied (not return content)",
        ],
    )

    add_title_and_bullets(
        prs,
        "Report B: Findings Overview (Speaker 4)",
        [
            "Method: AndroidManifest static analysis (not yet dynamically validated)",
            "Finding 1: TokenSharingService is exported and has no android:permission",
            "Finding 2: two Content Providers are exported and lack readPermission",
            "Conclusion: currently an exposed attack surface; needs proof of sensitive data access / usable tokens",
            "Why validation is needed: may have runtime checks, scoped URIs, or non-sensitive return data",
        ],
    )

    add_title_and_bullets(
        prs,
        "Report B: Fixes & Dynamic Validation Checklist (Speaker 5)",
        [
            "Fix (Service): add signature-level permission + enforce caller signature/identity checks",
            "Fix (Provider): add readPermission or enforce permission checks in query()",
            "Dynamic validation (bounty-critical): demonstrate access to sensitive columns/session tokens",
            "Dynamic validation (bounty-critical): demonstrate tokens are usable for auth and cause real impact",
            "Submission: provide reproducible steps + evidence (returned fields/samples, token usability validation)",
        ],
    )

    add_title_and_bullets(
        prs,
        "Comparison Summary & Close (Speaker 1)",
        [
            "Web: clear exploitation path and direct authorization bypass risk → more immediately actionable",
            "Android: static findings require dynamic evidence to confirm severity and claim bounty",
            "Shared principles: minimize exported surface, least privilege, and enforce server-side authorization",
            "Action: fix Web authorization first; in parallel harden Android components and complete dynamic validation",
        ],
    )

    output_path.parent.mkdir(parents=True, exist_ok=True)
    prs.save(str(output_path))


def main() -> int:
    out = Path(__file__).resolve().parents[1] / "Security_Reports_Quick_Briefing_6slides.pptx"
    build_deck(out)
    print(str(out))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

